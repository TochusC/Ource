void HariMain(void){
	for (;;) { }
}